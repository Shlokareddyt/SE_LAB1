TOPPINGS = {"cheese": 40, "olives": 30, "onion": 20, "paneer": 50}
SIZES = {"S": 8, "M": 10, "L": 12}

def toppings_price(toppings_csv):
    if not isinstance(toppings_csv, str) or not toppings_csv.strip():
        raise ValueError("Toppings must be a non-empty comma-separated string.")
    total = 0
    for t in toppings_csv.split(','):
        name = t.strip().lower()
        if name not in TOPPINGS:
            raise ValueError(f"Unknown topping: '{name}'")
        total += TOPPINGS[name]
    return total

def pizza_inches(size):
    if not isinstance(size, str) or not size.strip():
        raise ValueError("Size must be a non-empty string.")
    key = size.strip().upper()
    if key not in SIZES:
        raise ValueError(f"Unknown size: '{key}'. Choose from S, M, L.")
    return SIZES[key]

def split_bill(text):
    if not isinstance(text, str) or text.count('/') != 1:
        raise ValueError("Input must be in 'total/people' format.")
    total_str, people_str = text.split('/')
    try:
        total = int(total_str.strip())
        people = int(people_str.strip())
    except ValueError:
        raise ValueError("Total and people must be valid integers.")
    if people <= 0:
        raise ValueError("Number of people must be greater than zero.")
    return round(total / people, 2)

def main():
    print("==== Running toppings_price ====")
    user_input = input("Enter toppings as CSV (e.g. cheese,olives): ")
    try:
        print("Toppings Price:", toppings_price(user_input))
    except ValueError as e:
        print("Invalid input:", e)

    print("\n==== Running pizza_inches ====")
    user_input = input("Enter pizza size (S/M/L): ")
    try:
        print("Size in Inches:", pizza_inches(user_input))
    except ValueError as e:
        print("Invalid input:", e)

    print("\n==== Running split_bill ====")
    user_input = input("Enter total and people (e.g. 900/3): ")
    try:
        print("Per Person:", split_bill(user_input))
    except ValueError as e:
        print("Invalid input:", e)

if __name__ == "__main__":
    main()
