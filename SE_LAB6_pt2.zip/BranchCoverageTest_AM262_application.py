"""
Branch coverage test cases for pizza_order.py.

Builds on CodeCoverageTest_AM262_application.py. In addition to
executing every line at least once, each test below is chosen so that
every decision point (if / elif / else) in pizza_order.py is evaluated
for BOTH its True and False outcome, e.g.:
  - pizza_price: valid size vs. invalid size; toppings >= 0 vs. negative;
    toppings > 3 vs. toppings <= 3; cheese burst on vs. off; cheese burst
    with "small" (raises) vs. with another size.
  - order_discount: order_total < 300 vs. >= 300; day == "tuesday" vs.
    day in (saturday, sunday) vs. any other day; is_student True vs. False.
  - delivery_status: distance_km > 10 vs. <= 10; minutes_taken <= 30 vs.
    <= 45 vs. > 45.
"""
import pytest
from pizza_order import pizza_price, order_discount, delivery_status

# --- Original starter test cases ---
def test_plain_medium_pizza():
    assert pizza_price("medium", 0, False) == 350

def test_on_time_delivery():
    assert delivery_status(20, 3) == "on time"

# --- pizza_price: True/False of every condition ---
def test_invalid_size_raises():
    with pytest.raises(ValueError):
        pizza_price("xlarge", 0, False)

def test_negative_toppings_raises():
    with pytest.raises(ValueError):
        pizza_price("medium", -1, False)

def test_toppings_not_negative_is_fine():
    # toppings == 0 exercises the False branch of "toppings < 0"
    assert pizza_price("medium", 0, False) == 350

def test_few_toppings_price():
    # toppings <= 3 -> False branch of "toppings > 3"
    assert pizza_price("medium", 2, False) == 350 + 2 * 40

def test_many_toppings_price():
    # toppings > 3 -> True branch of "toppings > 3"
    assert pizza_price("large", 5, False) == 500 + 3 * 40 + 2 * 30

def test_no_cheese_burst_skips_block():
    # is_cheese_burst == False -> False branch of "if is_cheese_burst"
    assert pizza_price("large", 0, False) == 500

def test_cheese_burst_small_raises():
    # is_cheese_burst True, size == "small" -> True branch of inner if
    with pytest.raises(ValueError):
        pizza_price("small", 0, True)

def test_cheese_burst_medium_adds_cost():
    # is_cheese_burst True, size != "small" -> False branch of inner if
    assert pizza_price("medium", 0, True) == 350 + 100

# --- order_discount: True/False of every condition ---
def test_small_order_no_discount():
    # order_total < 300 -> True branch, early return
    assert order_discount(200, "monday", False) == 0

def test_tuesday_discount():
    # order_total >= 300 (False branch) then day == "tuesday" (True)
    assert order_discount(400, "tuesday", False) == 200

def test_weekend_no_discount():
    # day in (saturday, sunday) -> True branch of elif
    assert order_discount(400, "saturday", False) == 0
    assert order_discount(400, "sunday", False) == 0

def test_weekday_discount():
    # neither tuesday nor weekend -> else branch
    assert order_discount(400, "wednesday", False) == 40

def test_student_discount_true():
    # is_student True -> True branch
    assert order_discount(400, "wednesday", True) == 40 + 50

def test_student_discount_false():
    # is_student False -> False branch
    assert order_discount(400, "wednesday", False) == 40

# --- delivery_status: True/False of every condition ---
def test_far_delivery_not_deliverable():
    # distance_km > 10 -> True branch, early return
    assert delivery_status(10, 15) == "not deliverable"

def test_near_delivery_continues():
    # distance_km <= 10 -> False branch, falls through to time checks
    assert delivery_status(20, 3) == "on time"

def test_late_delivery():
    # minutes_taken <= 30 is False, <= 45 is True
    assert delivery_status(35, 5) == "late"

def test_free_pizza_delivery():
    # minutes_taken <= 30 is False, <= 45 is False -> final return
    assert delivery_status(50, 5) == "free pizza"
