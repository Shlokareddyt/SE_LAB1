# Lab 5 — Commit record

Full repo with live commit history (for verification):
**https://github.com/Shlokareddyt/L5_24_school_transport**

## Commit 1 — `a554bab` — fix: resolve Bandit security findings in school_transport.py

- Replace f-string SQL in enrollRider() with a parameterized query to eliminate
  the SQL injection vector (B608).
- Remove the shell=True subprocess call in dispatchAlert(); it only needs to
  announce the dispatch, so it now prints directly instead of shelling out,
  removing the command-injection risk (B602) and the subprocess-import
  flag (B404).
- Replace the bare except: in feeCollected() with except sqlite3.Error: so
  only database errors are swallowed.
- Replace the removable assert feeCollected(...) runtime check in main()
  with an explicit if/raise, since assert is stripped under python -O (B101).

Bandit: 4 issues (1 High, 1 Medium, 2 Low) -> 0 issues.

## Commit 2 — `8c22722` — refactor: resolve Pylint quality findings in school_transport.py

- Rename all functions to snake_case (enroll_rider, route_roster,
  export_roster, dispatch_alert, fee_collected) (C0103).
- Add a module docstring and a docstring for every function (C0114, C0116).
- Open the export file with with ... encoding="utf-8" instead of a bare
  open()/close(), fixing the resource leak and unspecified encoding
  (R1732, W1514).
- Drop the unused driver parameter from route_roster() and update its
  call site (W0613).
- Add an if __name__ == "__main__": guard around main().

Pylint: 4.00/10 -> 9.68/10.

## Commit 3 — `091ebb5` — style: resolve Flake8 formatting findings and add lab deliverables

- Wrap long SQL/table-definition lines and add spacing so every line is
  within PEP 8's line-length limit (E501, C0301).
- Add the missing blank line before dispatch_alert() (E302).
- Add before/after reports for Pylint, Bandit, and Flake8, plus the
  current pylint_report.txt, bandit_report.txt, flake8_report.txt.
- Add report.md documenting every issue found, how it was fixed, and the
  lab reflection questions.
- Ignore the generated route_r1.txt and the local venv/ directory.

Flake8: 8 violations -> 0 violations.
Final: Pylint 10.00/10, Bandit 0 issues, Flake8 0 issues.
