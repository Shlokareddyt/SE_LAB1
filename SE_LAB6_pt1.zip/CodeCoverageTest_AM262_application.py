import pytest
from pizza_order import pizza_price, order_discount, delivery_status

# --- Original starter test cases ---
def test_plain_medium_pizza():
    assert pizza_price("medium", 0, False) == 350

def test_on_time_delivery():
    assert delivery_status(20, 3) == "on time"

# --- pizza_price: additional test cases ---
def test_invalid_size_raises():
    with pytest.raises(ValueError):
        pizza_price("xlarge", 0, False)

def test_negative_toppings_raises():
    with pytest.raises(ValueError):
        pizza_price("medium", -1, False)

def test_many_toppings_price():
    # toppings > 3 -> flat 3*40 + extra toppings at 30 each
    assert pizza_price("large", 5, False) == 500 + 3 * 40 + 2 * 30

def test_cheese_burst_small_raises():
    with pytest.raises(ValueError):
        pizza_price("small", 0, True)

def test_cheese_burst_medium_adds_cost():
    assert pizza_price("medium", 0, True) == 350 + 100

# --- order_discount: additional test cases ---
def test_small_order_no_discount():
    assert order_discount(200, "monday", False) == 0

def test_tuesday_discount():
    assert order_discount(400, "tuesday", False) == 200

def test_weekend_no_discount():
    assert order_discount(400, "saturday", False) == 0

def test_weekday_discount():
    assert order_discount(400, "wednesday", False) == 40

def test_student_discount():
    assert order_discount(400, "wednesday", True) == 40 + 50

# --- delivery_status: additional test cases ---
def test_far_delivery_not_deliverable():
    assert delivery_status(10, 15) == "not deliverable"

def test_late_delivery():
    assert delivery_status(35, 5) == "late"

def test_free_pizza_delivery():
    assert delivery_status(50, 5) == "free pizza"
